<?php
session_start();
include 'admin/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form data
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $last_name = $_POST['last_name'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $nationality = $_POST['nationality'];
    $region = $_POST['region'];
    $city_woreda = $_POST['city_woreda'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $type_of_education = $_POST['type_of_education'];
    $education_level = $_POST['education_level'];
    $institution = $_POST['institution'];
    $job_responsibilities = $_POST['job_responsibilities'];
    $work_experience = $_POST['work_experience'];
    $work_type = $_POST['work_type'];
    $other_work_type = isset($_POST['other_work_type']) ? $_POST['other_work_type'] : '';
    $job_title = $_POST['job_title'];
    $description = $_POST['description'];
    $valid_from = $_POST['valid_from'];
    $valid_to = $_POST['valid_to'];
    $total_budget = $_POST['total_budget'];

    // Handle file upload
    $target_dir = "uploads/";
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    $target_file = $target_dir . basename($_FILES['cv_upload']['name']);
    if (!move_uploaded_file($_FILES['cv_upload']['tmp_name'], $target_file)) {
        $_SESSION['error'] = "Failed to upload file.";
        header("Location: reward.php");
        exit();
    }
    $cv_upload = $_FILES['cv_upload']['name'];

    // Insert data into database
    $stmt = $conn->prepare("INSERT INTO award (first_name, middle_name, last_name, gender, age, nationality, region, city_woreda, phone, email, type_of_education, education_level, institution, job_responsibilities, work_experience, work_type, other_work_type, job_title, description, valid_from, valid_to, total_budget, cv) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssissssssssssssssssss", $first_name, $middle_name, $last_name, $gender, $age, $nationality, $region, $city_woreda, $phone, $email, $type_of_education, $education_level, $institution, $job_responsibilities, $work_experience, $work_type, $other_work_type, $job_title, $description, $valid_from, $valid_to, $total_budget, $cv_upload);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Registration successful! Your status is pending.";
    } else {
        $_SESSION['error'] = "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
    header("Location: reward.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EIKRP</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }

        .form-container {
            margin-top: 50px;
        }

        .other-type {
            display: none;
        }
    </style>
    <!-- Google Translate API -->
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'am,en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    
</head>

<body>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="index.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h2 class="m-0 text-primary"><img width="350" height="60" src="img/logo.jpg" /></h2>
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                
                
                <a class="nav-item nav-link"href=""><div id="google_translate_element"></div></a>
            </div>

        </div>
    </nav>
    <!-- Navbar End -->
    <div class="container form-container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Application form for Award and recogenation</div>
                    <div class="card-body">
                        <form action="award.php" method="POST" enctype="multipart/form-data">
                            <div class="form-row">
                                <div class="form-group col-md-4">
                                    <label for="firstName">First Name</label>
                                    <input type="text" class="form-control" id="firstName" name="first_name" required>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="middleName">Middle Name</label>
                                    <input type="text" class="form-control" id="middleName" name="middle_name">
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="lastName">Last Name</label>
                                    <input type="text" class="form-control" id="lastName" name="last_name" required>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-3">
                                    <label for="gender">Gender</label>
                                    <select class="form-control" id="gender" name="gender" required>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                 
                                    </select>
                                </div>
                                <div class="form-group col-md-2">
                                    <label for="age">Age</label>
                                    <input type="number" class="form-control" id="age" name="age" required>
                                </div>
                                <div class="form-group col-md-3">
                                    <label for="nationality">Nationality</label>
                                    <input type="text" class="form-control" id="nationality" name="nationality" required>
                                </div>
                                <div class="form-group col-md-4">
                                    <label for="region">Region</label>
                                    <select class="form-control" id="region" name="region" required placeholder="select region" selected="none">
                                        <option value="Tigray">Tigray</option>
                                        <option value="Afar">Afar</option>
                                        <option value="Amhara">Amhara</option>
                                        <option value="Oromia">Oromia</option>
                                        <option value="Somali">Somali</option>
                                        <option value="Benishangul-Gumuz">Benishangul-Gumuz</option>
                                        <option value="Southern Nations, Nationalities and Peoples Region (SNNPR)">SNNPR</option>
                                        <option value="Gambella">Gambella</option>
                                        <option value="Harari">Harari</option>
                                        <option value="Addis Ababa">Addis Ababa</option>
                                        <option value="Dire Dawa">Dire Dawa</option>

                                    </select>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="cityWoreda">City/Woreda</label>
                                    <input type="text" class="form-control" id="cityWoreda" name="city_woreda" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="phone">Phone</label>
                                    <input type="tel" class="form-control" id="phone" name="phone" required>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="typeOfEducation">Type of Education</label>
                                    <input type="text" class="form-control" id="typeOfEducation" name="type_of_education" required>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="educationLevel">Education Level</label>
                                    <input type="text" class="form-control" id="educationLevel" name="education_level" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="institution">Institution</label>
                                    <input type="text" class="form-control" id="institution" name="institution" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="jobResponsibilities">Job Responsibilities</label>
                                <textarea class="form-control" id="jobResponsibilities" name="job_responsibilities" rows="3" required></textarea>
                            </div>
                            <div class="form-group">
                                <label for="workExperience">Work Experience</label>
                                <textarea class="form-control" id="workExperience" name="work_experience" rows="3" required></textarea>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="workType">Type of Work Submitted</label>
                                    <select class="form-control" id="workType" name="work_type" required>
                                        <option value="Research">Research</option>
                                        <option value="Innovation">Innovation</option>
                                        <option value="Technology">Technology</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                                <div class="form-group col-md-6 other-type">
                                    <label for="otherWorkType">Please specify</label>
                                    <textarea class="form-control" id="otherWorkType" name="other_work_type" rows="2"></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="jobTitle">Job Title</label>
                                <input type="text" class="form-control" id="jobTitle" name="job_title" required>
                            </div>
                            <div class="form-group">
                                <label for="description">Description of Support Requested</label>
                                <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
                            </div>
                            <div class="form-row">
                                <div class="form-group col-md-6">
                                    <label for="validFrom">Valid From</label>
                                    <input type="date" class="form-control" id="validFrom" name="valid_from" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="validTo">Valid To</label>
                                    <input type="date" class="form-control" id="validTo" name="valid_to" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="totalBudget">Total Budget Required</label>
                                <input type="number" class="form-control" id="totalBudget" name="total_budget" required>
                            </div>
                            <div class="form-group">
                                <label for="cvUpload">Upload CV</label>
                                <input type="file" class="form-control-file" id="cvUpload" name="cv_upload" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.getElementById('workType').addEventListener('change', function() {
            if (this.value === 'Other') {
                document.querySelector('.other-type').style.display = 'block';
            } else {
                document.querySelector('.other-type').style.display = 'none';
            }
        });
    </script>
</body>

</html>