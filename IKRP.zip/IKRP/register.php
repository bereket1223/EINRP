<?php
// Include the database connection file
include 'admin/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Directory to save uploads
    $targetDir = "uploads/";

    // Ensure the directory exists
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true); // Create the directory with appropriate permissions
    }

    // Initialize error array
    $errors = [];

    // Sanitize and validate inputs
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $gender = filter_input(INPUT_POST, 'gender', FILTER_SANITIZE_STRING);
    $age = filter_input(INPUT_POST, 'age', FILTER_SANITIZE_NUMBER_INT);
    $country = filter_input(INPUT_POST, 'country', FILTER_SANITIZE_STRING);
    $nationality = filter_input(INPUT_POST, 'nationality', FILTER_SANITIZE_STRING);
    $region = filter_input(INPUT_POST, 'region', FILTER_SANITIZE_STRING);
    $zone = filter_input(INPUT_POST, 'zone', FILTER_SANITIZE_STRING);
    $woreda = filter_input(INPUT_POST, 'woreda', FILTER_SANITIZE_STRING);
    $kebele = filter_input(INPUT_POST, 'kebele', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
    $categories = filter_input(INPUT_POST, 'categories', FILTER_SANITIZE_STRING);
    $service = filter_input(INPUT_POST, 'service', FILTER_SANITIZE_STRING);
    $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
    $permission = filter_input(INPUT_POST, 'permission', FILTER_SANITIZE_STRING);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);

    // Validate email
    if (!$email) {
        $errors[] = "Invalid email address.";
    }

    // Handle file uploads
    $fileUpload = $_FILES['fileUpload'];
    $videoUpload = $_FILES['videoUpload'];

    // Define allowed file types
    $allowedFileTypes = ['pdf', 'doc', 'docx', 'txt'];
    $allowedVideoTypes = ['mp4', 'avi', 'mov'];

    // Validate file uploads
    $fileExtension = strtolower(pathinfo($fileUpload['name'], PATHINFO_EXTENSION));
    $videoExtension = strtolower(pathinfo($videoUpload['name'], PATHINFO_EXTENSION));

    if (!in_array($fileExtension, $allowedFileTypes)) {
        $errors[] = "Invalid file type for file upload.";
    }
    if (!in_array($videoExtension, $allowedVideoTypes)) {
        $errors[] = "Invalid file type for video upload.";
    }

    // Check for file upload errors
    if ($fileUpload['error'] != UPLOAD_ERR_OK) {
        $errors[] = "Error uploading file.";
    }
    if ($videoUpload['error'] != UPLOAD_ERR_OK) {
        $errors[] = "Error uploading video.";
    }

    // Move uploaded files
    $fileTarget = $targetDir . basename($fileUpload['name']);
    $videoTarget = $targetDir . basename($videoUpload['name']);

    if (empty($errors)) {
        if (!move_uploaded_file($fileUpload['tmp_name'], $fileTarget) || !move_uploaded_file($videoUpload['tmp_name'], $videoTarget)) {
            $errors[] = "Error moving uploaded files.";
        }
    }

    // If no errors, proceed to insert data into the appropriate database table
    if (empty($errors)) {
        // Determine the table based on the selected category
        $tableName = '';
        if ($categories == 'research') {
            $tableName = 'researches';
        } elseif ($categories == 'innovation') {
            $tableName = 'innovations';
        } elseif ($categories == 'indigenous') {
            $tableName = 'indigenous';
        }

        if ($tableName) {
            // Set default status to 'Pending'
            $status = 'Pending';

            // Prepare and bind
            $stmt = $conn->prepare("INSERT INTO $tableName (name, gender, age, country, nationality, region, zone, woreda, kebele, email, phone, categories, service, title, fileUpload, videoUpload, permission, description, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssissssssssssssssss", $name, $gender, $age, $country, $nationality, $region, $zone, $woreda, $kebele, $email, $phone, $categories, $service, $title, $fileUpload['name'], $videoUpload['name'], $permission, $description, $status);

            if ($stmt->execute()) {
                // Determine the redirect URL based on the selected category
                $redirectUrl = 'index.php';
                if ($categories == 'research') {
                    $redirectUrl = 'research.php';
                } elseif ($categories == 'innovation') {
                    $redirectUrl = 'innovation.php';
                } elseif ($categories == 'indigenous') {
                    $redirectUrl = 'indigenous.php';
                }

                echo "<script>
                        alert('Registration successful! Your status is pending.check your email');
                        window.location.replace('$redirectUrl');
                        window.history.pushState(null, null, 'index.php');
                        window.onpopstate = function(event) {
                            window.location.href = 'index.php';
                        };
                      </script>";
                exit;
            } else {
                $errors[] = "Error: " . $stmt->error;
            }

            $stmt->close();
        } else {
            $errors[] = "Invalid category selected.";
        }
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo '<span class="error-msg">' . $error . '</span>';
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EIKRP</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <script src="https://kit.fontawesome.com/ae360af17e.js" crossorigin="anonymous"></script>
    <style>
        body {
            background-color: #f8f9fa;
            padding: 20px;
        }

        .form-container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .input-field {
            margin-bottom: 20px;
        }

        .form-btn {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 3px;
            cursor: pointer;
        }

        .form-btn:hover {
            background-color: #0056b3;
        }
    </style>
    </style>
    <!-- Google Translate API -->
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({
                pageLanguage: 'en',
                includedLanguages: 'am,en',
                layout: google.translate.TranslateElement.InlineLayout.SIMPLE
            }, 'google_translate_element');
        }
    </script>
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</head>

<body>
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light shadow sticky-top p-0">
        <a href="index.php" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h2 class="m-0 text-primary"><img width="350" height="60" src="img/logo.jpg" /></h2>
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">


                <a class="nav-item nav-link" href="">
                    <div id="google_translate_element"></div>
                </a>
            </div>

        </div>
    </nav>
    <!-- Navbar End -->
    <div class="form-container">
        <form id="registrationForm" action="register.php" method="post" enctype="multipart/form-data">
            <h2 class="mb-4">Registration Form for your indigenous knowledge </h2>

            <?php if (isset($errors)) {
                foreach ($errors as $error) {
                    echo '<div class="alert alert-danger">' . $error . '</div>';
                }
            } ?>

            <div class="form-group">
                <label for="name">Full Name:</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="gender">Gender:</label>
                <select class="form-control" id="gender" name="gender" required>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                </select>
            </div>
            <div class="form-group">
                <label for="age">Age:</label>
                <input type="number" class="form-control" id="age" name="age" required>
            </div>
            <div class="form-group">
                <label for="videoUpload">Video Upload (Max 1 minute):</label>
                <input type="file" class="form-control-file" id="videoUpload" name="videoUpload" accept="video/*" required>
                <small class="form-text text-muted">Allowed formats: MP4, MOV, AVI, etc.</small>
            </div>
            <div class="form-group">
                <label for="country">Country:</label>
                <input type="text" class="form-control" id="country" name="country" required>
            </div>
            <div class="form-group">
                <label for="nationality">Nationality:</label>
                <input type="text" class="form-control" id="nationality" name="nationality" required>
            </div>
            <div class="form-group">
                <label for="region">Region:</label>
                <select class="form-control" id="region" name="region" required>
                    <option value="Tigray">Tigray</option>
                    <option value="Afar">Afar</option>
                    <option value="Amhara">Amhara</option>
                    <option value="Oromia">Oromia</option>
                    <option value="Somali">Somali</option>
                    <option value="Benishangul-Gumuz">Benishangul-Gumuz</option>
                    <option value="Southern Nations, Nationalities and Peoples Region (SNNPR)">SNNPR</option>
                    <option value="Gambella">Gambella</option>
                    <option value="Harari">Harari</option>
                    <option value="Addis Ababa">Addis Ababa</option>
                    <option value="Dire Dawa">Dire Dawa</option>
                </select>
            </div>
            <div class="form-group">
                <label for="zone">Zone:</label>
                <input type="text" class="form-control" id="zone" name="zone" required>
            </div>
            <div class="form-group">
                <label for="woreda">Woreda:</label>
                <input type="text" class="form-control" id="woreda" name="woreda" required>
            </div>
            <div class="form-group">
                <label for="kebele">Kebele:</label>
                <input type="text" class="form-control" id="kebele" name="kebele" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>

                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number:</label>
                <input type="tel" class="form-control" id="phone" name="phone" required>
            </div>
            <div class="form-group">
                <label for="categories">main catagories:</label>
                <select class="form-control" id="categories" name="categories" required>
                    <option value="research">indigenous Research</option>
                    <option value="indigenous">indigenous technology</option>
                    <option value="innovation">indigenous Innovation</option>
                </select>
            </div>
            <div class="form-group">
                <label for="service">sub catagories:</label>
                <select class="form-control" id="service" name="service" required>
                    <option value="construction">agricalture</option>
                    <option value="food and beverages">food and beverages</option>
                    <option value="handicraft">handicraft</option>
                    <option value="scriptures">scriptures</option>
                    <option value="astronomy">astronomy</option>
                    <option value="construction">construction</option>
                    <option value="conflict resolution">conflict resolution</option>
                    <option value="emtertainment">entertainment</option>
                    <option value="traditional house building">traditional house building</option>
                    <option value="education system">education system</option>
                    <option value="coting industry">coting industry</option>
                    <option value="philosophy">philosophy</option>
                    <option value="traditional medicine">traditional medicine</option>

                </select>
            </div>
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>
            <div class="form-group">
                <label for="fileUpload">File Upload:</label>
                <input type="file" class="form-control-file" id="fileUpload" name="fileUpload" required>
                <small class="form-text text-muted">Allowed formats: PDF, DOC, DOCX, TXT.</small>
            </div>
            <div class="form-group">
                <label>Permission:</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" id="permissionYes" name="permission" value="yes" required>
                    <label class="form-check-label" for="permissionYes">Yes</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" id="permissionNo" name="permission" value="no">
                    <label class="form-check-label" for="permissionNo">No</label>
                </div>
            </div>
            <div class="form-group">
                <label for="description">Simple Description:</label>
                <textarea class="form-control" id="description" name="description" rows="2" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // Client-side validation for video upload
        document.getElementById('videoUpload').addEventListener('change', function() {
            const file = this.files[0];
            const fileSize = file.size;
            const fileType = file.type.split('/')[0];
            const allowedFileType = ['video'];

            // Check file type
            if (!allowedFileType.includes(fileType)) {
                alert('Invalid file type for video upload.');
                this.value = ''; // Reset file input
                return false;
            }

            // Check file size (1 minute max)
            const maxFileSize = 1024 * 1024 * 50; // 50 MB in bytes
            if (fileSize > maxFileSize) {
                alert('File size exceeds the limit (50 MB).');
                this.value = ''; // Reset file input
                return false;
            }

            // Check duration (1 minute)
            const video = document.createElement('video');
            video.preload = 'metadata';
            video.onloadedmetadata = function() {
                if (video.duration > 60) {
                    alert('Video duration must be within 1 minute.');
                    document.getElementById('videoUpload').value = ''; // Reset file input
                }
            };
            video.src = URL.createObjectURL(file);
        });
    </script>
</body>

</html>