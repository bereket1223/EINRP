<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $category = $_POST['category'];
    $message = $_POST['message'];
    $action = $_POST['action'];

    // Fetch email address
    $query = "SELECT email FROM $category WHERE id=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $email = $row['email'];

    // Send email
    $subject = ucfirst($action) . " Notification";
    $headers = "From: your-email@example.com";
    mail($email, $subject, $message, $headers);

    if ($action == 'approve') {
        // Update status to 'approved'
        $updateQuery = "UPDATE $category SET status='approved' WHERE id=?";
        $updateStmt = $conn->prepare($updateQuery);
        $updateStmt->bind_param('i', $id);
        $updateStmt->execute();
    } else if ($action == 'reject') {
        // Delete the row from the database
        $deleteQuery = "DELETE FROM $category WHERE id=?";
        $deleteStmt = $conn->prepare($deleteQuery);
        $deleteStmt->bind_param('i', $id);
        $deleteStmt->execute();
    }

    echo "Email sent successfully.";
}
?>
