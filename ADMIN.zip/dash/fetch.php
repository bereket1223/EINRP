<?php
include 'config.php';

// Function to fetch counts from database
function fetchCounts() {
    global $conn;

    $counts = array(
        'indigenous' => 0,
        'innovations' => 0,
        'researches' => 0,
        'awards' => 0
    );

    // Example SQL queries (replace with actual queries based on your database structure)
    $indigenousQuery = "SELECT COUNT(*) AS count FROM indigenous";
    $innovationsQuery = "SELECT COUNT(*) AS count FROM innovations";
    $researchesQuery = "SELECT COUNT(*) AS count FROM researches";
    $awardsQuery = "SELECT COUNT(*) AS count FROM award";

    // Execute queries and fetch counts
    $result = $conn->query($indigenousQuery);
    if ($result) {
        $row = $result->fetch_assoc();
        $counts['indigenous'] = $row['count'];
    } else {
        error_log("Error executing indigenous query: " . $conn->error);
    }

    $result = $conn->query($innovationsQuery);
    if ($result) {
        $row = $result->fetch_assoc();
        $counts['innovations'] = $row['count'];
    } else {
        error_log("Error executing innovations query: " . $conn->error);
    }

    $result = $conn->query($researchesQuery);
    if ($result) {
        $row = $result->fetch_assoc();
        $counts['researches'] = $row['count'];
    } else {
        error_log("Error executing researches query: " . $conn->error);
    }

    $result = $conn->query($awardsQuery);
    if ($result) {
        $row = $result->fetch_assoc();
        $counts['award'] = $row['count'];
    } else {
        error_log("Error executing awards query: " . $conn->error);
    }

    return $counts;
}

// Usage example:
$counts = fetchCounts();

// Construct custom format
$output = "";
foreach ($counts as $key => $value) {
    $output .= "{$key}={$value}&";
}

// Remove the last '&' character
$output = rtrim($output, '&');

// Output the custom format
echo $output;

$conn->close();
?>
