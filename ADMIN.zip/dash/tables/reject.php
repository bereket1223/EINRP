<?php
include 'config.php';

$id = $_GET['id'];

// Update status to 'Rejected'
$sql = "UPDATE researches SET status = 'Rejected' WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();

// Redirect to admin page after action
header("Location: ../list.php");
exit;
?>
