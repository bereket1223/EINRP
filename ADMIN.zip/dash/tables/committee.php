<?php
include 'config.php';

// Fetch all records from the committee table
$committees = $conn->query("SELECT * FROM committee");

function displayCommittees($result)
{
    global $conn;
    echo "<h2>records that ready to evaluate </h2>";
    if ($result->num_rows > 0) {
        echo "<div class='table-responsive'>
                <table class='table table-bordered table-striped'>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>First Name</th>
                            <th>Middle Name</th>
                            <th>Last Name</th>
                            <th>Gender</th>
                            <th>Age</th>
                            <th>Nationality</th>
                            <th>Region</th>
                            <th>City/Woreda</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Type of Education</th>
                            <th>Education Level</th>
                            <th>Institution</th>
                            <th>Job Responsibilities</th>
                            <th>Work Experience</th>
                            <th>Work Type</th>
                            <th>Other Work Type</th>
                            <th>Job Title</th>
                            <th>Description</th>
                            <th>Valid From</th>
                            <th>Valid To</th>
                            <th>Total Budget</th>
                            <th>CV</th>
                            <th>Evaluator1</th>
                            <th>Evaluator2</th>
                            <th>Evaluator3</th>
                            <th>Evaluator4</th>
                            <th>Evaluator5</th>
                            <th>Evaluator6</th>
                            <th>Last Modified</th>
                            <th>Action</th> <!-- Added for transfer action -->
                        </tr>
                    </thead>
                    <tbody>";
        while ($row = $result->fetch_assoc()) {
            // Check each evaluator column and display link or "Evaluated"
            $evaluator1Display = $row['evaluator1'] ? "Evaluated" : "<a href='/dash/committee/evaluator1.php?id={$row['id']}'>Evaluator 1</a>";
            $evaluator2Display = $row['evaluator2'] ? "Evaluated" : "<a href='/dash/committee/evaluator2.php?id={$row['id']}'>Evaluator 2</a>";
            $evaluator3Display = $row['evaluator3'] ? "Evaluated" : "<a href='/dash/committee/evaluator3.php?id={$row['id']}'>Evaluator 3</a>";
            $evaluator4Display = $row['evaluator4'] ? "Evaluated" : "<a href='/dash/committee/evaluator4.php?id={$row['id']}'>Evaluator 4</a>";
            $evaluator5Display = $row['evaluator5'] ? "Evaluated" : "<a href='/dash/committee/evaluator5.php?id={$row['id']}'>Evaluator 5</a>";
            $evaluator6Display = $row['evaluator6'] ? "Evaluated" : "<a href='/dash/committee/evaluator6.php?id={$row['id']}'>Evaluator 6</a>";

            // Determine if all evaluators have evaluated
            $allEvaluated = $row['evaluator1'] && $row['evaluator2'] && $row['evaluator3'] && $row['evaluator4'] && $row['evaluator5'] && $row['evaluator6'];

            // Action button to transfer to award table
            $actionButton = $allEvaluated ? "<a href='/dash/committee/transfer_to_award.php?id={$row['id']}' class='btn btn-primary'>Transfer to Award</a>" : "Pending";

            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['first_name']}</td>
                    <td>{$row['middle_name']}</td>
                    <td>{$row['last_name']}</td>
                    <td>{$row['gender']}</td>
                    <td>{$row['age']}</td>
                    <td>{$row['nationality']}</td>
                    <td>{$row['region']}</td>
                    <td>{$row['city_woreda']}</td>
                    <td>{$row['phone']}</td>
                    <td><a href='mailto:{$row['email']}'>{$row['email']}</a></td>
                    <td>{$row['type_of_education']}</td>
                    <td>{$row['education_level']}</td>
                    <td>{$row['institution']}</td>
                    <td>{$row['job_responsibilities']}</td>
                    <td>{$row['work_experience']}</td>
                    <td>{$row['work_type']}</td>
                    <td>{$row['other_work_type']}</td>
                    <td>{$row['job_title']}</td>
                    <td>{$row['description']}</td>
                    <td>{$row['valid_from']}</td>
                    <td>{$row['valid_to']}</td>
                    <td>{$row['total_budget']}</td>
                    <td><a href='http://localhost/dash/download.php?file_id={$row['id']}&file_type=file&category=research' target='_blank'>Download File</a></td>
                    <td>{$evaluator1Display}</td>
                    <td>{$evaluator2Display}</td>
                    <td>{$evaluator3Display}</td>
                    <td>{$evaluator4Display}</td>
                    <td>{$evaluator5Display}</td>
                    <td>{$evaluator6Display}</td>
                    <td>{$row['last_modified']}</td>
                    <td>{$actionButton}</td>
                </tr>";
        }
        echo "</tbody></table></div>";
    } else {
        echo "<p>No committee records found.</p>";
    }
}

echo "<div>";
displayCommittees($committees);
echo "</div>";

$conn->close();
