<?php
include 'config.php';

$id = $_GET['id'];

// Update status to 'Approved'
$sql = "UPDATE researches SET status = 'Approved' WHERE id = $id";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();

// Redirect to admin page after action
header("Location: ../admin.php");
exit;
?>
