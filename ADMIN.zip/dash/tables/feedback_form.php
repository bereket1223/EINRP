<?php
// Ensure ID and action are set and valid
if (isset($_GET['id']) && isset($_GET['action']) && ($_GET['action'] == 'accept' || $_GET['action'] == 'reject')) {
    $id = $_GET['id'];
    $action = $_GET['action'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Feedback Form</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script>
        function showFeedbackForm() {
            const userConfirmed = confirm("Do you want to accept this invention?");
            if (userConfirmed) {
                document.getElementById('feedback').value = 'yes';
                document.getElementById('feedbackForm').submit();
            } else {
                window.location.href = 'list.php'; // Redirect to another page if No
            }
        }

        window.onload = function() {
            showFeedbackForm();
        };
    </script>
</head>
<body>
    <div class="container mt-4">
        <h2>Feedback Form for Action: <?php echo ucfirst($action); ?></h2>
        <form id="feedbackForm" method="post" action="handle_feedback.php" style="display: none;">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <input type="hidden" name="action" value="<?php echo $action; ?>">
            <div class="form-group">
                <label>Feedback:</label>
                <textarea id="feedback" name='feedback' rows='4' cols='50' class='form-control' placeholder='Enter feedback'></textarea>
            </div>
        </form>
    </div>
</body>
</html>

<?php
} else {
    // Invalid request handling (redirect or error message)
    echo "Invalid request.";
}
?>
