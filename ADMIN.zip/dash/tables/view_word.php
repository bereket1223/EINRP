<?php
$file_path = $_GET['file_path'];
header('Content-type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
header('Content-Disposition: inline; filename="' . basename($file_path) . '"');
@readfile($file_path);
