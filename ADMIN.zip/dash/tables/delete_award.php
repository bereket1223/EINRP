<?php
include 'config.php';

// Check if the ID is set in the URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Ensure the ID is an integer

    // Prepare the DELETE query
    $deleteQuery = $conn->prepare("DELETE FROM award WHERE id = ?");
    $deleteQuery->bind_param("i", $id);

    // Execute the query
    if ($deleteQuery->execute()) {
        // Record deleted successfully
        header("Location: /dash/admindash.php?message=Record deleted successfully");
        exit();
    } else {
        // Error occurred while deleting the record
        header("Location: /dash/admindash.php?error=Error deleting record");
        exit();
    }
} else {
    // If ID is not set, redirect to the dashboard or a default page
    header("Location: : /dash/admindash.php");
    exit();
}

$conn->close();
?>
