<?php
// Include database connection
include 'config.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize inputs
    $feedback = filter_input(INPUT_POST, 'feedback', FILTER_SANITIZE_STRING);
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);

    // Validate the inputs
    if (!$id || !$action) {
        die("Invalid input.");
    }

    // Determine the table and new status based on the action
    $table = '';
    $new_status = '';

    if ($action == 'accept') {
        $new_status = 'Accepted';
    } elseif ($action == 'reject') {
        $new_status = 'Rejected';
    } else {
        die("Invalid action.");
    }

    // Update feedback and status in the database
    $stmt = $conn->prepare("UPDATE researches SET  status = ? WHERE id = ?");
    $stmt->bind_param("si", $new_status, $id);
    $stmt->execute();

    $stmt = $conn->prepare("UPDATE innovations SET  status = ? WHERE id = ?");
    $stmt->bind_param("si", $new_status, $id);
    $stmt->execute();

    $stmt = $conn->prepare("UPDATE indigenous SET  status = ? WHERE id = ?");
    $stmt->bind_param("si", $new_status, $id);
    $stmt->execute();
   
    $stmt->close();
    $conn->close();

    // Redirect back to the tables page
    header("Location: ../admindash.php");
    exit();
} else {
    die("Invalid request.");
}
