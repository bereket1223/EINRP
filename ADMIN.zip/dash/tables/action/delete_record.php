<?php
include 'config.php';

if (isset($_GET['id']) && isset($_GET['category'])) {
    $id = intval($_GET['id']);
    $category = $_GET['category'];

    // Determine the table based on the category
    $tableName = '';
    if ($category == 'research') {
        $tableName = 'researches';
    } elseif ($category == 'innovation') {
        $tableName = 'innovations';
    } elseif ($category == 'indigenous') {
        $tableName = 'indigenous';
    }

    if ($tableName) {
        // Prepare and execute the delete statement
        $stmt = $conn->prepare("DELETE FROM $tableName WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            echo "<script>
                    alert('Record deleted successfully.');
                    window.location.href = 'dash/tables/admindash.php';
                  </script>";
        } else {
            echo "Error deleting record: " . $conn->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>
