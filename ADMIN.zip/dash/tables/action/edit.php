<?php
include 'db.php';

$id = $_GET['id'];
$category = $_GET['category'];
$tableName = '';

if ($category == 'research') {
    $tableName = 'researches';
} elseif ($category == 'innovation') {
    $tableName = 'innovations';
} elseif ($category == 'indigenous') {
    $tableName = 'indigenous';
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate inputs
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $gender = filter_input(INPUT_POST, 'gender', FILTER_SANITIZE_STRING);
    $age = filter_input(INPUT_POST, 'age', FILTER_SANITIZE_NUMBER_INT);
    $country = filter_input(INPUT_POST, 'country', FILTER_SANITIZE_STRING);
    $nationality = filter_input(INPUT_POST, 'nationality', FILTER_SANITIZE_STRING);
    $region = filter_input(INPUT_POST, 'region', FILTER_SANITIZE_STRING);
    $zone = filter_input(INPUT_POST, 'zone', FILTER_SANITIZE_STRING);
    $woreda = filter_input(INPUT_POST, 'woreda', FILTER_SANITIZE_STRING);
    $kebele = filter_input(INPUT_POST, 'kebele', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
    $categories = filter_input(INPUT_POST, 'catagories', FILTER_SANITIZE_STRING);
    $service = filter_input(INPUT_POST, 'service', FILTER_SANITIZE_STRING);
    $title = filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING);
    $permission = filter_input(INPUT_POST, 'permission', FILTER_SANITIZE_STRING);
    $description = filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING);

    // Prepare and bind
    $stmt = $conn->prepare("UPDATE $tableName SET name=?, gender=?, age=?, country=?, nationality=?, region=?, zone=?, woreda=?, kebele=?, email=?, phone=?, catagories=?, service=?, title=?, permission=?, description=? WHERE id=?");
    $stmt->bind_param("ssisssssssssssssi", $name, $gender, $age, $country, $nationality, $region, $zone, $woreda, $kebele, $email, $phone, $categories, $service, $title, $permission, $description, $id);

    if ($stmt->execute()) {
        echo "<script>
                alert('Update successful!');
                window.location.href = 'admin.php';
              </script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    $result = $conn->query("SELECT * FROM $tableName WHERE id=$id");

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Display edit form with existing data
        ?>
        <form method="POST" action="">
            <!-- Add form fields with pre-filled data from the database -->
            <input type="text" name="name" value="<?php echo $row['name']; ?>" required>
  
            <!-- Add other fields similarly -->
            <input type="submit" value="Update">
        </form>
        <?php
    } else {
        echo "Record not found.";
    }
}

$conn->close();
?>
