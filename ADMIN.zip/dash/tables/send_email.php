<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $action = $_POST['action'];
    $message = $_POST['message'];

    if ($action === 'accept') {
        $query = "UPDATE registrations SET status = 'Accepted' WHERE id = $id";
        $result = mysqli_query($conn, $query);

        if ($result) {
            $query = "SELECT * FROM registrations WHERE id = $id";
            $result = mysqli_query($conn, $query);
            $user = mysqli_fetch_assoc($result);

            // Send acceptance email
            $to = $user['email'];
            $subject = 'Registration Accepted';
            $message = "Dear {$user['name']},\n\nYour registration has been accepted.\n\nFeedback: $message";
            mail($to, $subject, $message);

            header("Location: table.php");
        } else {
            echo "Error updating record: " . mysqli_error($conn);
        }
    } elseif ($action === 'reject') {
        $query = "DELETE FROM registrations WHERE id = $id";
        $result = mysqli_query($conn, $query);

        if ($result) {
            $query = "SELECT * FROM registrations WHERE id = $id";
            $result = mysqli_query($conn, $query);
            $user = mysqli_fetch_assoc($result);

            // Send rejection email
            $to = $user['email'];
            $subject = 'Registration Rejected';
            $message = "Dear {$user['name']},\n\nYour registration has been rejected.\n\nFeedback: $message";
            mail($to, $subject, $message);

            header("Location: table.php");
        } else {
            echo "Error deleting record: " . mysqli_error($conn);
        }
    } else {
        echo "Invalid action";
    }
}

$conn->close();
?>
