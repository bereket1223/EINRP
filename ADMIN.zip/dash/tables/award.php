<?php
include 'config.php';

// Function to calculate the average of evaluators' ratings
function calculateAverage($evaluator1, $evaluator2, $evaluator3, $evaluator4, $evaluator5, $evaluator6)
{
    // Convert empty values to 0 for calculation
    $evaluators = [$evaluator1, $evaluator2, $evaluator3, $evaluator4, $evaluator5, $evaluator6];
    $validEvaluators = array_filter($evaluators, function ($value) {
        return $value !== null && $value !== '';
    });

    if (empty($validEvaluators)) {
        return 0;
    }

    $average = array_sum($validEvaluators) / count($validEvaluators);
    return round($average, 2); // Round to 2 decimal places
}

// Fetch all records from the award table ordered by rate in descending order
$awards = $conn->query("SELECT * FROM award ORDER BY average DESC");

function displayAwards($conn, $result)
{
    echo "<h2>Registration Records for Awards and Recognitions</h2>";
    if ($result->num_rows > 0) {
        echo "<div class='table-responsive'>
                <table class='table table-bordered table-striped'>
                    <thead class='thead-dark'>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Gender</th>
                            <th>Age</th>
                            <th>Nationality</th>
                            <th>Region</th>
                            <th>City/Woreda</th>
                            <th>Phone</th>
                            <th>Email</th>
                            <th>Type of Education</th>
                            <th>Education Level</th>
                            <th>Institution</th>
                            <th>Job Responsibilities</th>
                            <th>Work Experience</th>
                            <th>Work Type</th>
                            <th>Other Work Type</th>
                            <th>Job Title</th>
                            <th>Description</th>
                            <th>Valid From</th>
                            <th>Valid To</th>
                            <th>Total Budget</th>
                            <th>CV</th>
                            <th>Average</th>
                            <th>Evaluator1</th>
                            <th>Evaluator2</th>
                            <th>Evaluator3</th>
                            <th>Evaluator4</th>
                            <th>Evaluator5</th>
                            <th>Evaluator6</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>";
        while ($row = $result->fetch_assoc()) {
            // Calculate average if all evaluators have provided ratings
            $average = calculateAverage($row['evaluator1'], $row['evaluator2'], $row['evaluator3'], $row['evaluator4'], $row['evaluator5'], $row['evaluator6']);

            // Update the average in the award table
            $updateQuery = $conn->prepare("UPDATE award SET average = ? WHERE id = ?");
            $updateQuery->bind_param("di", $average, $row['id']);
            $updateQuery->execute();

            // Check if all evaluators have completed their evaluations
            if ($row['evaluator1'] && $row['evaluator2'] && $row['evaluator3'] && $row['evaluator4'] && $row['evaluator5'] && $row['evaluator6']) {
                $actionButton = "<button class='btn btn-success btn-sm' disabled>Done</button>";
            } else {
                $actionButton = "
                    <a href='/dash/send_to_committee.php?id={$row['id']}' class='btn btn-primary btn-sm' onclick='return confirm(\"Send to committee?\")'>Send to Committee</a>
                    <a href='delete_award.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Delete this record?\")'>Delete</a>";
            }

            echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['first_name']} {$row['middle_name']} {$row['last_name']}</td>
                    <td>{$row['gender']}</td>
                    <td>{$row['age']}</td>
                    <td>{$row['nationality']}</td>
                    <td>{$row['region']}</td>
                    <td>{$row['city_woreda']}</td>
                    <td>{$row['phone']}</td>
                    <td><a href='mailto:{$row['email']}'>{$row['email']}</a></td>
                    <td>{$row['type_of_education']}</td>
                    <td>{$row['education_level']}</td>
                    <td>{$row['institution']}</td>
                    <td>{$row['job_responsibilities']}</td>
                    <td>{$row['work_experience']}</td>
                    <td>{$row['work_type']}</td>
                    <td>{$row['other_work_type']}</td>
                    <td>{$row['job_title']}</td>
                    <td>{$row['description']}</td>
                    <td>{$row['valid_from']}</td>
                    <td>{$row['valid_to']}</td>
                    <td>{$row['total_budget']}</td>
                    <td><a href='http://localhost/dash/download.php?file_id={$row['id']}&file_type=file&category=research' target='_blank'>Download File</a></td>
                    <td>{$average}</td>
                    <td>{$row['evaluator1']}</td>
                    <td>{$row['evaluator2']}</td>
                    <td>{$row['evaluator3']}</td>
                    <td>{$row['evaluator4']}</td>
                    <td>{$row['evaluator5']}</td>
                    <td>{$row['evaluator6']}</td>
                    <td>{$actionButton}</td>
                </tr>";
        }
        echo "</tbody></table></div>";
    } else {
        echo "<p>No awards found.</p>";
    }
}

echo "<div class='container mt-4'>";
displayAwards($conn, $awards);
echo "</div>";

$conn->close();
