<?php
$file_path = $_GET['file_path'];
header('Content-type: application/pdf');
header('Content-Disposition: inline; filename="' . basename($file_path) . '"');
@readfile($file_path);
?>
