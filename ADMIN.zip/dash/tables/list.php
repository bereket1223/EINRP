<?php
include 'config.php';

// Function to display records
function displayRecords($result, $category)
{
    echo "<h2>" . ucfirst($category) . "</h2>";
    if ($result->num_rows > 0) {
        echo "<div class='table-responsive'>
                <div class='input-group mb-3'>
                    <div class='input-group-prepend'>
                        <span class='input-group-text'>Search {$category}</span>
                    </div>
                    <input type='text' class='form-control search-input' placeholder='Enter search keyword...' data-category='{$category}'>
                    <div class='input-group-append'>
                        <span class='input-group-text'><i class='fa fa-search'></i></span>
                    </div>
                </div>
                <table class='table table-bordered table-striped'>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Gender</th>
                            <th>Age</th>
                            <th>Country</th>
                            <th>Nationality</th>
                            <th>Region</th>
                            <th>Zone</th>
                            <th>Woreda</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Category</th>
                            <th>Service</th>
                            <th>Title</th>
                            <th>File</th>
                            <th>Video</th>
                            <th>Permission</th>
                            <th>Description</th>
                            <th>Timestamp</th>
                            <th>Status</th>
                            <th>Action</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr id='row-{$row['id']}'>
                    <td>{$row['id']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['gender']}</td>
                    <td>{$row['age']}</td>
                    <td>{$row['country']}</td>
                    <td>{$row['nationality']}</td>
                    <td>{$row['region']}</td>
                    <td>{$row['zone']}</td>
                    <td>{$row['woreda']}</td>
                    <td><a href='mailto:{$row['email']}'>{$row['email']}</a></td>
                    <td>{$row['phone']}</td>
                    <td>{$row['categories']}</td>
                    <td>{$row['service']}</td>
                    <td>{$row['title']}</td>
                    <td><a href='http://localhost/dash/download.php?file_id={$row['id']}&file_type=file&category=research' target='_blank'>Download File</a></td>
                    <td><a href='http://localhost/dash/download1.php?file_id={$row['id']}&file_type=vedio&category=research' target='_blank'>Download video</a></td>                    
                    <td>{$row['permission']}</td>
                    <td>{$row['description']}</td>
                    <td>{$row['created_at']}</td>
                    <td>{$row['status']}</td>
                    <td>";

            // Display different actions based on status
            if ($row['status'] == 'Pending') {
                echo "<a class='btn btn-success' href='tables/feedback_form.php?id={$row['id']}&action=accept&email={$row['email']}'>Accept</a>
                      <a class='btn btn-danger' href='tables/feedback_form.php?id={$row['id']}&action=reject&email={$row['email']}'>Reject</a>";
            } elseif ($row['status'] == 'Accepted') {
                echo "Accepted";
            } elseif ($row['status'] == 'Rejected') {
                echo "Rejected";
            }

            echo "</td><td>";

            // Display delete button only if status is 'Rejected'
            if ($row['status'] == 'Rejected') {
                echo "<a class='btn btn-danger' href='tables/action/delete_record.php?id={$row['id']}&category=$category' onclick='return confirm(\"Are you sure you want to delete this record?\")'>Delete</a>";
            }

            echo "</td></tr>";
        }
        echo "</tbody></table></div>";
    } else {
        echo "<p>No records found in $category category.</p>";
    }
}

// Fetch all records from all categories
$researches = $conn->query("SELECT * FROM researches");
$innovations = $conn->query("SELECT * FROM innovations");
$indigenous = $conn->query("SELECT * FROM indigenous");

// Display records for each category
echo "<div>";
displayRecords($researches, 'research');
displayRecords($innovations, 'innovation');
displayRecords($indigenous, 'indigenous');
echo "</div>";

$conn->close();
?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.search-input').forEach(function(searchInput) {
            searchInput.addEventListener('input', function() {
                const searchText = this.value.trim().toLowerCase();
                const category = this.getAttribute('data-category');
                const table = document.querySelector(`table[data-category='${category}']`);
                const rows = table.getElementsByTagName('tr');

                for (let row of rows) {
                    const cells = row.getElementsByTagName('td');
                    let found = false;

                    for (let cell of cells) {
                        const text = cell.textContent.trim().toLowerCase();
                        if (text.includes(searchText)) {
                            found = true;
                            cell.classList.add('bg-info', 'text-white'); // Highlight the cell
                            break;
                        } else {
                            cell.classList.remove('bg-info', 'text-white'); // Remove highlight if not found
                        }
                    }

                    row.style.display = found ? '' : 'none';
                }
            });
        });
    });
</script>