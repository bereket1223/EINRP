<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $criteria1 = $_POST['criteria1'];
    $criteria2 = $_POST['criteria2'];
    $criteria3 = $_POST['criteria3'];
    $criteria4 = $_POST['criteria4'];
    $criteria5 = $_POST['criteria5'];
    $criteria6 = $_POST['criteria6'];
    $criteria7 = $_POST['criteria7'];

  
    $sum = $criteria1 + $criteria2 + $criteria3 + $criteria4 + $criteria5 + $criteria6 + $criteria7;
    $stmt = $conn->prepare("UPDATE committee SET evaluator2 = ? WHERE id = ?");
    $stmt->bind_param('di', $sum, $id); // Note: use 'd' for double and 'i' for integer
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Evaluation submitted successfully!'); window.location.href = '/dash/committee/committee.php';</script>";
    exit;
}

$id = $_GET['id'];
$committee = $conn->query("SELECT * FROM committee WHERE id = $id")->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evaluator 2</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script>
        function calculateSum() {
            const criteria = [
                parseFloat(document.getElementById('criteria1').value) || 0,
                parseFloat(document.getElementById('criteria2').value) || 0,
                parseFloat(document.getElementById('criteria3').value) || 0,
                parseFloat(document.getElementById('criteria4').value) || 0,
                parseFloat(document.getElementById('criteria5').value) || 0,
                parseFloat(document.getElementById('criteria6').value) || 0,
                parseFloat(document.getElementById('criteria7').value) || 0,
            ];
            const sum = criteria.reduce((acc, val) => acc + val, 0);
            document.getElementById('sum').value = sum;
        }
    </script>
</head>
<body>
    <div class="container mt-5">
        <h2>Evaluation for <?php echo $committee['first_name'] . ' ' . $committee['last_name']; ?></h2>
        <p>Phone: <?php echo $committee['phone']; ?></p>
        <form method="POST" action="">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="form-group">
                <label for="criteria1">economic importance</label>
                <input type="number" class="form-control" id="criteria1" min="0" max="10" name="criteria1" required oninput="calculateSum()">
            </div>
            <div class="form-group">
                <label for="criteria2">social importance</label>
                <input type="number" class="form-control" id="criteria2" min="0" max="20" name="criteria2" required oninput="calculateSum()">
            </div>
            <div class="form-group">
                <label for="criteria3">enviromental importance</label>
                <input type="number" class="form-control" id="criteria3" min="0" max="10" name="criteria3" required oninput="calculateSum()">
            </div>
            <div class="form-group">
                <label for="criteria4">state of the innovation</label>
                <input type="number" class="form-control" id="criteria4" min="0" max="20" name="criteria4" required oninput="calculateSum()">
            </div>
            <div class="form-group">
                <label for="criteria5">functionality</label>
                <input type="number" class="form-control" id="criteria5" min="0" max="15" name="criteria5" required oninput="calculateSum()">
            </div>
            <div class="form-group">
                <label for="criteria6">is it the first work?</label>
                <input type="number" class="form-control" id="criteria6" min="0" max="15" name="criteria6" required oninput="calculateSum()">
            </div>
            <div class="form-group">
                <label for="criteria7">is it continous</label>
                <input type="number" class="form-control" id="criteria7" min="0" max="10" name="criteria7" required oninput="calculateSum()">
            </div>
            <div class="form-group">
                <label for="sum">Sum</label>
                <input type="number" class="form-control" id="sum" name="sum" readonly>
            </div>
            <button type="submit" class="btn btn-primary">Submit Evaluation</button>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
