<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the committee record
    $committeeQuery = $conn->query("SELECT * FROM committee WHERE id = $id");
    if ($committeeQuery->num_rows > 0) {
        $committee = $committeeQuery->fetch_assoc();

        // Check if all evaluators have completed their evaluations
        if ($committee['evaluator1'] && $committee['evaluator2'] && $committee['evaluator3'] && $committee['evaluator4'] && $committee['evaluator5'] && $committee['evaluator6']) {

            // Insert or update into the award table using ON DUPLICATE KEY UPDATE
            $stmt = $conn->prepare("INSERT INTO award (id, first_name, middle_name, last_name, gender, age, nationality, region, city_woreda, phone, email, type_of_education, education_level, institution, job_responsibilities, work_experience, work_type, other_work_type, job_title, description, valid_from, valid_to, total_budget, cv, evaluator1, evaluator2, evaluator3, evaluator4, evaluator5, evaluator6)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                                    ON DUPLICATE KEY UPDATE
                                    first_name = VALUES(first_name),
                                    middle_name = VALUES(middle_name),
                                    last_name = VALUES(last_name),
                                    gender = VALUES(gender),
                                    age = VALUES(age),
                                    nationality = VALUES(nationality),
                                    region = VALUES(region),
                                    city_woreda = VALUES(city_woreda),
                                    phone = VALUES(phone),
                                    email = VALUES(email),
                                    type_of_education = VALUES(type_of_education),
                                    education_level = VALUES(education_level),
                                    institution = VALUES(institution),
                                    job_responsibilities = VALUES(job_responsibilities),
                                    work_experience = VALUES(work_experience),
                                    work_type = VALUES(work_type),
                                    other_work_type = VALUES(other_work_type),
                                    job_title = VALUES(job_title),
                                    description = VALUES(description),
                                    valid_from = VALUES(valid_from),
                                    valid_to = VALUES(valid_to),
                                    total_budget = VALUES(total_budget),
                                    cv = VALUES(cv),
                                    evaluator1 = VALUES(evaluator1),
                                    evaluator2 = VALUES(evaluator2),
                                    evaluator3 = VALUES(evaluator3),
                                    evaluator4 = VALUES(evaluator4),
                                    evaluator5 = VALUES(evaluator5),
                                    evaluator6 = VALUES(evaluator6)");
            $stmt->bind_param("issssissssssssssssssssssssssss", 
                $committee['id'], 
                $committee['first_name'], 
                $committee['middle_name'], 
                $committee['last_name'], 
                $committee['gender'], 
                $committee['age'], 
                $committee['nationality'], 
                $committee['region'], 
                $committee['city_woreda'], 
                $committee['phone'], 
                $committee['email'], 
                $committee['type_of_education'], 
                $committee['education_level'], 
                $committee['institution'], 
                $committee['job_responsibilities'], 
                $committee['work_experience'], 
                $committee['work_type'], 
                $committee['other_work_type'], 
                $committee['job_title'], 
                $committee['description'], 
                $committee['valid_from'], 
                $committee['valid_to'], 
                $committee['total_budget'], 
                $committee['cv'], 
                $committee['evaluator1'], 
                $committee['evaluator2'], 
                $committee['evaluator3'], 
                $committee['evaluator4'], 
                $committee['evaluator5'], 
                $committee['evaluator6']
            );

            if ($stmt->execute()) {
                // Delete the record from committee table after successful transfer (optional)
                $deleteQuery = $conn->query("DELETE FROM committee WHERE id = $id");

                if ($deleteQuery) {
                    echo "<script>alert('Record transferred to award successfully.'); window.location.href = '/dash/admindash.php';</script>";
                } else {
                    echo "<script>alert('Error deleting record from committee table.'); window.location.href = 'committee.php';</script>";
                }
            } else {
                echo "<script>alert('Error transferring record to award table.'); window.location.href = 'committee.php';</script>";
            }

            $stmt->close();
        } else {
            echo "<script>alert('Not all evaluators have completed their evaluations.'); window.location.href = 'committee.php';</script>";
        }
    } else {
        echo "<script>alert('Record not found in committee table.'); window.location.href = 'committee.php';</script>";
    }
} else {
    echo "<script>alert('Invalid request.'); window.location.href = 'committee.php';</script>";
}

$conn->close();
?>
