<?php
include 'config.php';

if (!isset($_GET['id'])) {
    echo "No record selected.";
    exit;
}

$id = $_GET['id'];

// Fetch the committee record
$committeeRecord = $conn->query("SELECT * FROM committee WHERE id = $id")->fetch_assoc();

if (!$committeeRecord) {
    echo "Committee record not found.";
    exit;
}

// Check if the rate is set
if (is_null($committeeRecord['rate'])) {
    echo "No rate available to send.";
    exit;
}

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO award (id, first_name, middle_name, last_name, gender, age, nationality, region, city_woreda, phone, email, type_of_education, education_level, institution, job_responsibilities, work_experience, work_type, other_work_type, job_title, description, valid_from, valid_to, total_budget, cv, rate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE first_name=VALUES(first_name), middle_name=VALUES(middle_name), last_name=VALUES(last_name), gender=VALUES(gender), age=VALUES(age), nationality=VALUES(nationality), region=VALUES(region), city_woreda=VALUES(city_woreda), phone=VALUES(phone), email=VALUES(email), type_of_education=VALUES(type_of_education), education_level=VALUES(education_level), institution=VALUES(institution), job_responsibilities=VALUES(job_responsibilities), work_experience=VALUES(work_experience), work_type=VALUES(work_type), other_work_type=VALUES(other_work_type), job_title=VALUES(job_title), description=VALUES(description), valid_from=VALUES(valid_from), valid_to=VALUES(valid_to), total_budget=VALUES(total_budget), cv=VALUES(cv), rate=VALUES(rate)");
$stmt->bind_param("issssisssssssssssssssssss", 
    $committeeRecord['id'], 
    $committeeRecord['first_name'], 
    $committeeRecord['middle_name'], 
    $committeeRecord['last_name'], 
    $committeeRecord['gender'], 
    $committeeRecord['age'], 
    $committeeRecord['nationality'], 
    $committeeRecord['region'], 
    $committeeRecord['city_woreda'], 
    $committeeRecord['phone'], 
    $committeeRecord['email'], 
    $committeeRecord['type_of_education'], 
    $committeeRecord['education_level'], 
    $committeeRecord['institution'], 
    $committeeRecord['job_responsibilities'], 
    $committeeRecord['work_experience'], 
    $committeeRecord['work_type'], 
    $committeeRecord['other_work_type'], 
    $committeeRecord['job_title'], 
    $committeeRecord['description'], 
    $committeeRecord['valid_from'], 
    $committeeRecord['valid_to'], 
    $committeeRecord['total_budget'], 
    $committeeRecord['cv'], 
    $committeeRecord['rate']
);

if ($stmt->execute()) {
    // Update the committee table to indicate the record has been sent to admin
    $conn->query("UPDATE committee SET send_to_admin = 1 WHERE id = $id");
    echo "<script>alert('Record sent to award table successfully.'); window.location.href = 'committee.php';</script>";
} else {
    echo "<script>alert('Error sending record to award table.');</script>";
}

$stmt->close();
$conn->close();
?>
