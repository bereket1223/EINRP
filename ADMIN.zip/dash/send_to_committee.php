<?php
include 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the award details
    $award = $conn->query("SELECT * FROM award WHERE id = $id")->fetch_assoc();

    if ($award) {
        // Check if the record already exists in the committee table
        $checkCommittee = $conn->query("SELECT * FROM committee WHERE id = $id");

        if ($checkCommittee->num_rows == 0) {
            // Insert the record into the committee table
            $stmt = $conn->prepare("INSERT INTO committee (id, first_name, middle_name, last_name, gender, age, nationality, region, city_woreda, phone, email, type_of_education, education_level, institution, job_responsibilities, work_experience, work_type, other_work_type, job_title, description, valid_from, valid_to, total_budget, cv) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("issssissssssssssssssssss", $award['id'], $award['first_name'], $award['middle_name'], $award['last_name'], $award['gender'], $award['age'], $award['nationality'], $award['region'], $award['city_woreda'], $award['phone'], $award['email'], $award['type_of_education'], $award['education_level'], $award['institution'], $award['job_responsibilities'], $award['work_experience'], $award['work_type'], $award['other_work_type'], $award['job_title'], $award['description'], $award['valid_from'], $award['valid_to'], $award['total_budget'], $award['cv']);

            if ($stmt->execute()) {
                echo "<script>alert('Record sent to committee successfully.'); window.location.href = 'admindash.php';</script>";
            } else {
                echo "<script>alert('Error sending record to committee.'); window.location.href = '../index.php';</script>";
            }

            $stmt->close();
        } else {
            echo "<script>alert('Record already exists in committee table.'); window.location.href = '../index.php';</script>";
        }
    } else {
        echo "<script>alert('Record not found.'); window.location.href = '../index.php';</script>";
    }
}

$conn->close();
?>
