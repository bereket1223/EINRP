<?php
session_start();
include 'config.php';

$msg = "";

if (isset($_POST['submit'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Check in admin table first
    $sql_admin = "SELECT * FROM admin WHERE email='{$email}' AND password='{$password}'";
    $result_admin = mysqli_query($conn, $sql_admin);

    if (mysqli_num_rows($result_admin) === 1) {
        $_SESSION['SESSION_EMAIL'] = $email;
        header("Location: admindash.php");
        exit();
    } else {
        // Check in users table if not found in admin table
        $sql_user = "SELECT * FROM users WHERE email='{$email}' AND password='{$password}'";
        $result_user = mysqli_query($conn, $sql_user);

        if (mysqli_num_rows($result_user) === 1) {
            $_SESSION['SESSION_EMAIL'] = $email;
            header("Location: committee/committee.php");
            exit();
        } else {
            $msg = "<div class='alert alert-danger'>Email or password do not match.</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="login.css"> <!-- Custom styles -->
    <script src="https://kit.fontawesome.com/af562a2a63.js" crossorigin="anonymous"></script>
</head>

<body>

    <section class="w3l-mockup-form">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 col-md-8">
                    <div class="card shadow-lg p-3 mb-5 rounded">
                        <div class="card-body">
                            <div class="alert-close">
                                <span class="fa fa-close"></span>
                            </div>
                            <div class="text-center">
                                <img src="image/integration.jpg" alt="" class="img-fluid mb-4">
                                <h2>LOGIN NOW</h2>
                                <p>WELCOME DEAR, TO LOG INTO ADMIN USE ADMIN EMAIL AND PASSWORD, TO LOGIN COMMITTEE DASHBOARD USE COMMITTEE EMAIL AND PASSWORD</p>
                            </div>
                            <?php echo $msg; ?>
                            <form action="" method="post">
                                <div class="form-group">
                                    <input type="email" class="form-control" name="email" placeholder="Enter Your Email" required>
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="password" placeholder="Enter Your Password" required>
                                </div>
                                <button name="submit" class="btn btn-primary btn-block" type="submit">Login</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>