<?php
// Include the database connection file
include 'config.php';

// Check if the required query parameters are set
if (!isset($_GET['file_id'], $_GET['file_type'], $_GET['category'])) {
    die('Missing required parameters.');
}

// Get the file ID, file type, and category from the URL query string
$fileId = $_GET['file_id'];
$fileType = $_GET['file_type'];
$category = $_GET['category'];

// Determine the table name based on the category
$tableName = '';
switch ($category) {
    case 'research':
        $tableName = 'researches';
        break;
    case 'indigenous':
        $tableName = 'indigenous';
        break;
    case 'innovation':
        $tableName = 'innovations';
        break;
    default:
        die('Invalid category.');
}

// Query the database to get the file information
$stmt = $conn->prepare("SELECT videoUpload FROM $tableName WHERE id = ?");
$stmt->bind_param("i", $fileId);
$stmt->execute();
$stmt->bind_result($fileName);
$stmt->fetch();
$stmt->close();

// Verify that the file name was retrieved correctly
if (!$fileName) {
    die("No file found for ID $fileId in category $category.");
}

// Determine the file extension
$fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
if ($fileType === 'video') {
    // Set the appropriate content type for videos
    switch ($fileExtension) {
        case 'mp4':
            header('Content-Type: video/mp4');
            break;
        case 'avi':
            header('Content-Type: video/x-msvideo');
            break;
        case 'mov':
            header('Content-Type: video/quicktime');
            break;
        default:
            die('Invalid video file type.');
    }
    header('Content-Disposition: attachment; filename="' . basename($fileName) . '"');
}

// Path to the file
$filePath = 'uploads/' . $fileName;

// Debug: Check if the file exists
if (!file_exists($filePath)) {
    die("File not found: " . $filePath);
}

// Output the file content
readfile($filePath);

// Close the database connection
$conn->close();
